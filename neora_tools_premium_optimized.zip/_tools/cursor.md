---
title: "Cursor"
url: "https://cursor.sh"
affiliate_url: ""
category: "code"
badge: "free"
rating: 4.9
icon: "⌨️"
desc_ar: "Cursor من أفضل أدوات الذكاء الاصطناعي في فئته، يساعد على زيادة الإنتاجية، أتمتة المهام، وتحقيق نتائج احترافية بسرعة وسهولة."
desc_en: "Cursor is one of the leading AI tools in its category, helping users automate tasks, improve productivity, and achieve professional results."
pricing_ar: "مجاني"
---
