---
title: "ChatGPT"
url: "https://chatgpt.com"
affiliate_url: ""
category: "chat"
badge: "free"
rating: 4.9
icon: "💬"
desc_ar: "مساعد الذكاء الاصطناعي الأشهر من OpenAI للكتابة والبحث والبرمجة والترجمة وإنشاء المحتوى."
desc_en: "OpenAI's flagship AI assistant for writing, coding, research, translation, and productivity."
pricing_ar: "مجاني مع خطط مدفوعة"
pricing_en: "Free with premium plans"
---
