---
title: "Tome"
url: "https://tome.app"
affiliate_url: ""
category: "productivity"
badge: "free"
rating: 4.5
icon: "📜"
desc_ar: "Tome من أفضل أدوات الذكاء الاصطناعي في فئته، يساعد على زيادة الإنتاجية، أتمتة المهام، وتحقيق نتائج احترافية بسرعة وسهولة."
desc_en: "Tome is one of the leading AI tools in its category, helping users automate tasks, improve productivity, and achieve professional results."
pricing_ar: "مجاني"
---
