---
title: "Llama"
url: "https://llama.meta.com"
affiliate_url: ""
category: "chat"
badge: "free"
rating: 4.6
icon: "🦙"
desc_ar: "نموذج الذكاء الاصطناعي مفتوح المصدر من Meta. الأقوى بين النماذج المجانية المفتوحة."
desc_en: "Meta's open-source AI model. The most powerful among free open-source AI models."
pricing_ar: "مجاني تماماً ومفتوح المصدر"
---
