---
title: "Veo 2"
url: "https://deepmind.google/technologies/veo"
affiliate_url: ""
category: "video"
badge: "pro"
rating: 4.8
icon: "🎬"
desc_ar: "نموذج توليد الفيديو من Google DeepMind. ينتج فيديوهات واقعية بجودة سينمائية مذهلة."
desc_en: "Google DeepMind's video generation model. Produces cinematic quality realistic videos."
pricing_ar: "ضمن Google One AI Premium"
---
