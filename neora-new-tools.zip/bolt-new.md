---
title: "Bolt.new"
url: "https://bolt.new"
affiliate_url: ""
category: "code"
badge: "free"
rating: 4.8
icon: "⚡"
desc_ar: "بناء تطبيقات ويب كاملة بالذكاء الاصطناعي في ثوانٍ. من أكثر أدوات الكود انتشاراً الآن."
desc_en: "Build full-stack web apps with AI in seconds. One of the most popular AI coding tools right now."
pricing_ar: "مجاني / $20 شهرياً"
---
