---
title: "Hailuo AI"
url: "https://hailuoai.video"
affiliate_url: ""
category: "video"
badge: "free"
rating: 4.7
icon: "🌊"
desc_ar: "منصة توليد فيديو صينية انتشرت بقوة على السوشيال ميديا. جودة عالية ومجانية جزئياً."
desc_en: "Chinese AI video generator that went viral on social media. High quality with a free tier."
pricing_ar: "مجاني / اشتراكات متاحة"
---
