---
title: "Lovable"
url: "https://lovable.dev"
affiliate_url: ""
category: "code"
badge: "free"
rating: 4.7
icon: "💜"
desc_ar: "إنشاء مواقع ويب وتطبيقات كاملة بالذكاء الاصطناعي. اكتب وصف مشروعك واحصل على موقع جاهز."
desc_en: "Create full websites and apps with AI. Describe your project and get a ready-to-deploy site."
pricing_ar: "مجاني / $20 شهرياً"
---
