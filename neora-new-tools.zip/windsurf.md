---
title: "Windsurf"
url: "https://codeium.com/windsurf"
affiliate_url: ""
category: "code"
badge: "free"
rating: 4.8
icon: "🏄"
desc_ar: "محرر كود ذكي من Codeium. منافس قوي لـ Cursor مع ذكاء اصطناعي متقدم وفهم عميق للمشاريع."
desc_en: "AI-powered code editor by Codeium. A strong Cursor competitor with deep project understanding."
pricing_ar: "مجاني / $15 شهرياً"
---
