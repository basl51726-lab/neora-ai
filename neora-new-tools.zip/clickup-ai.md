---
title: "ClickUp AI"
url: "https://clickup.com/ai"
affiliate_url: ""
category: "productivity"
badge: "free"
rating: 4.6
icon: "✅"
desc_ar: "منصة إدارة مشاريع شاملة مع ذكاء اصطناعي مدمج. منافس قوي لـ Notion مع ميزات أكثر."
desc_en: "Comprehensive project management platform with built-in AI. A strong Notion competitor."
pricing_ar: "مجاني / $7+ شهرياً"
---
